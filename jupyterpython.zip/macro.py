import selenium
from selenium import webdriver
from selenium.webdriver import ActionChains

from selenium.webdriver.common.key import Keys
from slennium.webdriver.common.by import By

from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import select
from selenium.webdriver.support.ui import webDriverWait

URL="https://www.nike.com/kr"

driver = webdriver.Firefox()
driver.get(url=URL)